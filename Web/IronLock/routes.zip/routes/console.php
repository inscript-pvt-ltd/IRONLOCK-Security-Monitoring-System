<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

// Flag shifts whose check-in/start window has expired as missed, so the
// "contact your supervisor" recovery path surfaces promptly on the app and
// the admin dashboard. Overlap-protected so a slow run never double-fires.
Schedule::command('shifts:mark-missed')->everyMinute()->withoutOverlapping();

// Guarantee every shift closes: force-close any Active shift left open past its
// scheduled_end + grace (a guard who forgot to end, or a dead/offline phone).
// Spec: Details/Important/BACKEND_SHIFT_END_SPEC.md §2. Overlap-protected.
Schedule::command('shifts:auto-close')->everyFiveMinutes()->withoutOverlapping();

// Time out photo requests the guard never answered within the 90s window and
// raise a CRITICAL alert (spec §16.4). Runs every minute. Overlap-protected.
Schedule::command('photos:timeout-sweep')->everyMinute()->withoutOverlapping();

// Fire verification photo checks at their provisioned schedule marks (Phase 7
// Option A; spec §8.2). Runs every minute so a due mark is dispatched promptly;
// the command skips shifts with an unanswered request and never double-fires a
// mark. The marks are randomised at shift start, so checks stay unpredictable.
// Overlap-protected.
Schedule::command('photos:dispatch-scheduled')->everyMinute()->withoutOverlapping();

// Fire online wakefulness challenges at their provisioned schedule marks
// (spec §9.4.1). Runs every minute so a due mark is dispatched promptly; the
// command skips shifts with an unanswered challenge and never double-fires a
// mark. Overlap-protected.
Schedule::command('wakefulness:dispatch')->everyMinute()->withoutOverlapping();

// Fail wakefulness challenges the guard never answered within the 60s response
// window and raise a CRITICAL alert (spec §9.5). Runs every minute.
// Overlap-protected.
Schedule::command('wakefulness:timeout-sweep')->everyMinute()->withoutOverlapping();

// Alert on a scheduled photo/wakefulness verification mark that fell inside a
// closed comms gap and left no trace at all — neither an offline capture
// flushed by the device nor an online catch-up dispatch (both dispatchers
// deliberately skip firing a mark once it's older than
// catchup_staleness_seconds). Previously this only produced a neutral,
// report-only "Missed" note; this promotes it to a CRITICAL, is_offline
// alert on the Alert Feed / dashboard. Runs every minute. Overlap-protected.
Schedule::command('schedule:missed-sweep')->everyMinute()->withoutOverlapping();

// Remove monthly evidence backups whose 30-day retention has elapsed (deletes
// the backup record + cached ZIP only — never the original evidence). Daily.
Schedule::command('ironlock:backups-cleanup')->dailyAt('03:30')->withoutOverlapping();

// Raise SIA licence-expiry alerts (Phase 8 · REP-004) for active guards whose
// licence is expired or expiring within the warning window. Idempotent per
// guard per day, so a daily run never spams the Alert Feed.
Schedule::command('sia:check-expiry')->dailyAt('06:00')->withoutOverlapping();

// Prune regenerable/past-policy data (generated reports, closed alerts, and —
// only if explicitly configured — raw evidence) past the retention horizons in
// config('ironlock.retention'). NEVER touches the append-only shift_events.
Schedule::command('retention:sweep')->dailyAt('04:00')->withoutOverlapping();
